<?php
/*
* MessengerEngineInterface.php - Interface file
*
* This file is part of the Messenger component.
*-----------------------------------------------------------------------------*/

namespace App\Exp\Components\Messenger\Interfaces;

interface MessengerEngineInterface
{ 

}