<?php
/*
* TranslationEngineInterface.php - Interface file
*
* This file is part of the Translation component.
*-----------------------------------------------------------------------------*/

namespace App\Exp\Components\Translation\Interfaces;

interface TranslationEngineInterface
{ 

}