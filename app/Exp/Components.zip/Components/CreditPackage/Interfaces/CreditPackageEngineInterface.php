<?php
/*
* CreditPackageEngineInterface.php - Interface file
*
* This file is part of the CreditPackage component.
*-----------------------------------------------------------------------------*/

namespace App\Exp\Components\CreditPackage\Interfaces;

interface CreditPackageEngineInterface
{ 

}