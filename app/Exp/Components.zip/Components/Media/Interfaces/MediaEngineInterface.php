<?php
/*
* MediaEngineInterface.php - Interface file
*
* This file is part of the Media component.
*-----------------------------------------------------------------------------*/

namespace App\Exp\Components\Media\Interfaces;

interface MediaEngineInterface
{ 

}