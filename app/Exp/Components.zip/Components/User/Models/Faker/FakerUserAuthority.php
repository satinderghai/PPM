<?php
namespace App\Exp\Components\User\Models\Faker;
use App\Exp\Components\User\Models\UserAuthorityModel;

class FakerUserAuthority extends UserAuthorityModel
{
	//timestamp false
	public $timestamps = false;
}