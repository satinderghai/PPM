<?php
namespace App\Exp\Components\User\Models\Faker;

use App\Exp\Components\User\Models\User;

class FakerUserModel extends User
{
	//timestamp false
	public $timestamps = false;
}