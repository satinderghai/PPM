<?php
namespace App\Exp\Components\User\Models\Faker;
use App\Exp\Components\User\Models\UserProfile;

class FakerUserProfile extends UserProfile
{
	//timestamp false
	public $timestamps = false;
}