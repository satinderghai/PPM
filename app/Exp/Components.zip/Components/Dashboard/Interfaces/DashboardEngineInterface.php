<?php
/*
* DashboardEngineInterface.php - Interface file
*
* This file is part of the Dashboard component.
*-----------------------------------------------------------------------------*/

namespace App\Exp\Components\Dashboard\Interfaces;

interface DashboardEngineInterface
{ 

}