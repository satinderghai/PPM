<?php
/*
* HomeEngineInterface.php - Interface file
*
* This file is part of the Home component.
*-----------------------------------------------------------------------------*/

namespace App\Exp\Components\Home\Interfaces;

interface HomeEngineInterface
{ 

}